package com.ali.tradingjournal

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("journal", MODE_PRIVATE) }
    private var selectedId = ""
    private lateinit var root: LinearLayout
    private lateinit var challengeSpinner: Spinner
    private lateinit var summary: TextView
    private lateinit var tradesBox: LinearLayout

    private fun challenges(): JSONArray = try { JSONArray(prefs.getString("challenges", "[]")) } catch (_: Exception) { JSONArray() }
    private fun trades(): JSONArray = try { JSONArray(prefs.getString("trades", "[]")) } catch (_: Exception) { JSONArray() }
    private fun saveChallenges(a: JSONArray) { prefs.edit().putString("challenges", a.toString()).apply() }
    private fun saveTrades(a: JSONArray) { prefs.edit().putString("trades", a.toString()).apply() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = challenges()
        if (c.length() == 0) {
            c.put(JSONObject().put("id", "${System.currentTimeMillis()}").put("name", "چالش اول").put("firm", "Prop Firm").put("capital", 10000.0).put("target", 8.0).put("maxLoss", 10.0))
            saveChallenges(c)
        }
        buildScreen()
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 18, 20, 16); setBackgroundColor(0xFFF4F6F9.toInt()) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        content.addView(text("ژورنال معاملاتی", 26, true, 0xFF0D2744.toInt()))
        content.addView(text("مدیریت چند چالش، ثبت معاملات و کنترل ریسک", 14, false, 0xFF526170.toInt()))
        content.addView(gap(14))
        content.addView(text("انتخاب چالش", 16, true, 0xFF172B4D.toInt()))
        challengeSpinner = Spinner(this)
        content.addView(challengeSpinner)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        buttons.addView(button("+ چالش جدید") { addChallenge() }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(button("+ ثبت معامله") { addTrade() }, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(buttons)
        content.addView(gap(12))
        summary = text("", 16, true, 0xFF172B4D.toInt())
        summary.setPadding(14, 14, 14, 14)
        summary.setBackgroundColor(0xFFFFFFFF.toInt())
        content.addView(summary)
        content.addView(gap(12))
        content.addView(text("معاملات چالش انتخاب‌شده", 18, true, 0xFF0D2744.toInt()))
        tradesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(tradesBox)
        refresh()
    }

    private fun text(s: String, size: Int, bold: Boolean, color: Int): TextView = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(0, 6, 0, 6)
    }
    private fun gap(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }
    private fun field(hint: String, type: Int = android.text.InputType.TYPE_CLASS_TEXT): EditText = EditText(this).apply { this.hint = hint; inputType = type; setSingleLine(true) }

    private fun currentChallenge(): JSONObject? {
        val a = challenges()
        for (i in 0 until a.length()) if (a.optJSONObject(i)?.optString("id") == selectedId) return a.optJSONObject(i)
        return a.optJSONObject(0)
    }

    private fun refresh() {
        val cs = challenges(); val names = ArrayList<String>(); var index = 0
        for (i in 0 until cs.length()) { val ch = cs.optJSONObject(i) ?: continue; names.add("${ch.optString("name")} — ${ch.optString("firm")}"); if (ch.optString("id") == selectedId) index = names.lastIndex }
        challengeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        if (cs.length() > 0) {
            if (selectedId.isBlank()) selectedId = cs.optJSONObject(index)?.optString("id", "") ?: ""
            val selectedIndex = (0 until cs.length()).firstOrNull { cs.optJSONObject(it)?.optString("id") == selectedId } ?: 0
            challengeSpinner.setSelection(selectedIndex)
        }
        challengeSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedId = cs.optJSONObject(position)?.optString("id", "") ?: ""; renderSummary(); renderTrades()
            }
        }
        renderSummary(); renderTrades()
    }

    private fun renderSummary() {
        val ch = currentChallenge() ?: run { summary.text = "چالشی وجود ندارد"; return }
        var pnl = 0.0; var wins = 0; var count = 0
        val ts = trades()
        for (i in 0 until ts.length()) { val t = ts.optJSONObject(i) ?: continue; if (t.optString("challengeId") == ch.optString("id")) { count++; val p = t.optDouble("pnl", 0.0); pnl += p; if (p > 0) wins++ } }
        val capital = ch.optDouble("capital", 0.0)
        summary.text = "${ch.optString("name")}\nشرکت: ${ch.optString("firm")}\nسرمایه اولیه: ${fmt(capital)}\nسود/زیان ثبت‌شده: ${fmt(pnl)}\nتعداد معاملات: $count  |  برد: $wins\nهدف سود: ${ch.optDouble("target", 0.0)}%  |  حد ضرر کل: ${ch.optDouble("maxLoss", 0.0)}%"
    }

    private fun renderTrades() {
        tradesBox.removeAllViews(); val ts = trades(); var shown = 0
        for (i in ts.length() - 1 downTo 0) {
            val t = ts.optJSONObject(i) ?: continue
            if (t.optString("challengeId") != selectedId) continue
            shown++
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 8, 12, 8); setBackgroundColor(0xFFFFFFFF.toInt()) }
            card.addView(text("${t.optString("symbol")} | ${t.optString("direction")} | ${t.optString("date")}", 16, true, 0xFF172B4D.toInt()))
            card.addView(text("نتیجه: ${fmt(t.optDouble("pnl", 0.0))}  |  ریسک: ${t.optString("risk")}%\nدلیل ورود: ${t.optString("reason")}\nیادداشت: ${t.optString("note")}", 14, false, 0xFF526170.toInt()))
            tradesBox.addView(card); tradesBox.addView(gap(8))
        }
        if (shown == 0) tradesBox.addView(text("هنوز معامله‌ای برای این چالش ثبت نشده است.", 14, false, 0xFF526170.toInt()))
    }

    private fun addChallenge() {
        val name = field("نام چالش (مثلاً مرحله اول)")
        val firm = field("نام شرکت پراپ")
        val capital = field("سرمایه حساب (مثلاً 10000)", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val target = field("هدف سود درصدی (مثلاً 8)", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val maxLoss = field("حد ضرر کل درصدی (مثلاً 10)", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(name); addView(firm); addView(capital); addView(target); addView(maxLoss) }
        AlertDialog.Builder(this).setTitle("افزودن چالش").setView(box).setNegativeButton("انصراف", null).setPositiveButton("ذخیره") { _, _ ->
            if (name.text.isBlank()) { toast("نام چالش را وارد کن"); return@setPositiveButton }
            val ch = JSONObject().put("id", "${System.currentTimeMillis()}").put("name", name.text.toString()).put("firm", firm.text.toString().ifBlank { "Prop Firm" }).put("capital", capital.text.toString().toDoubleOrNull() ?: 0.0).put("target", target.text.toString().toDoubleOrNull() ?: 0.0).put("maxLoss", maxLoss.text.toString().toDoubleOrNull() ?: 0.0)
            val a = challenges(); a.put(ch); saveChallenges(a); selectedId = ch.optString("id"); refresh()
        }.show()
    }

    private fun addTrade() {
        if (currentChallenge() == null) { toast("اول یک چالش بساز"); return }
        val symbol = field("نماد (مثلاً XAUUSD)")
        val direction = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Buy", "Sell")) }
        val pnl = field("سود/زیان به مبلغ (منفی برای ضرر)", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val risk = field("ریسک درصدی معامله", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val reason = field("دلیل ورود")
        val note = field("خطا یا یادداشت")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(symbol); addView(direction); addView(pnl); addView(risk); addView(reason); addView(note) }
        AlertDialog.Builder(this).setTitle("ثبت معامله").setView(box).setNegativeButton("انصراف", null).setPositiveButton("ذخیره") { _, _ ->
            val t = JSONObject().put("id", "${System.currentTimeMillis()}").put("challengeId", selectedId).put("symbol", symbol.text.toString().ifBlank { "XAUUSD" }).put("direction", direction.selectedItem.toString()).put("pnl", pnl.text.toString().toDoubleOrNull() ?: 0.0).put("risk", risk.text.toString()).put("reason", reason.text.toString()).put("note", note.text.toString()).put("date", java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()))
            val a = trades(); a.put(t); saveTrades(a); refresh()
        }.show()
    }

    private fun fmt(n: Double): String = String.format(java.util.Locale.US, "%.2f", n)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
